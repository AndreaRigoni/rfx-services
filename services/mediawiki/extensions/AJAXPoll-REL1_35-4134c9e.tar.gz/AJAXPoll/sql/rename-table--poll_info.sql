RENAME TABLE /*_*/poll_info TO /*_*/ajaxpoll_info;
