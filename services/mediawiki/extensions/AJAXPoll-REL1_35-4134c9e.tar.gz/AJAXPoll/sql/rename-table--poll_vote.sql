RENAME TABLE /*_*/poll_vote TO /*_*/ajaxpoll_vote;
