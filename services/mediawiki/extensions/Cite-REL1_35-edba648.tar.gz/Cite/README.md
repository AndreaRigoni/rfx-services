Cite
=============

The Cite extension provides a way for users to create references as footnotes to articles.

See https://www.mediawiki.org/wiki/Extension:Cite for detailed documentation.
