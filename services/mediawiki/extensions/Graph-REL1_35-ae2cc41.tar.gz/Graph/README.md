Graph is a MediaWiki extension that uses Vega JS to visualize almost arbitrary data in almost arbitrary ways.
See  https://www.mediawiki.org/wiki/Extension:Graph
