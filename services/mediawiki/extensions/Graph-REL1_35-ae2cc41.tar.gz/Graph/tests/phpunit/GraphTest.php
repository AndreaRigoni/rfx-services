<?php

namespace Graph\Tests;

use MediaWikiTestCase;

/**
 * @package GraphTests
 * @group Graph
 */
class GraphTest extends MediaWikiTestCase {

}
