<?php

namespace MediaWiki\Extension\LDAPAuthorization;

class Setup {
	public static function onRegistration() {
	}
}
