<?php

namespace MediaWiki\Extension\LDAPProvider;

class EncType {
	public const LDAPI = 'ldapi';
	public const SSL = 'ssl';
	public const TLS = 'tls';
	public const CLEAR = 'clear';
}
