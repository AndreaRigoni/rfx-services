<?php

namespace MediaWiki\Extension\LDAPUserInfo;

class Config {
	const DOMAINCONFIG_SECTION = 'userinfo';
	const ATTRIBUTES_MAP = 'attributes-map';
	const GENERIC_PROPERTY_NORMALIZATION_CALLBACKS = 'generic-property-normalization-callbacks';
}
