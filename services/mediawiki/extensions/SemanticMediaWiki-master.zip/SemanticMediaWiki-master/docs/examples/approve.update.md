Certain user scenarios may require to refuse or alter an update by changing the revision that builds the basis for the semantic data stored in Semantic MediaWiki.

Please see the [`Semantic ApprovedRevs`][ssc] extension for details on how and which hooks to be used in connection with Semantic MediaWiki.

[ssc]:https://github.com/SemanticMediaWiki/SemanticApprovedRevs
