Released on August 20, 2011.

* #ask queries now allow printouts (table columns) that are exactly the same.
  In previous versions, multiple printouts with the same label would be
  collapsed (e.g. {{#ask: [[Catgegory:City]] |?|?|?}} now shows four columns).
* Fixed continue and limit escaping issues on Special:Ask.
* Fixed error occurring for invalid queries with count or debug formats.
* Fixed several small issues with the table format and cleaned it up somewhat.
* Fixed parsing of years for data properties.
* Internationalization improvements and layout tweaks to #smwdoc.