# Semantic MediaWiki 1.9.1.1

Released February 28th, 2014.

### Bug fixes

* #183 Fixed 1.9.1 regression in resource paths that caused resouces not to load

### Internal enhancements

* #200 Improved the usage of "InternalParseBeforeLinks" to indicate whether semantic data have been processed or not
