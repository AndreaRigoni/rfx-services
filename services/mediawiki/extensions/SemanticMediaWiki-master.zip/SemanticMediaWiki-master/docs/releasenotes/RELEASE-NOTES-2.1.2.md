# Semantic MediaWiki 2.1.2

Released on March 28th, 2015.

## Bug fixes

* #882 Fixed exception in `SMWExportController` caused by an empty reference
* #885 Fixed pre tag rendering in template output
* #896 Fixed empty string for boolean x-format output
