# Semantic MediaWiki 2.1.3

Released on March 30th, 2015.

## Bug fix

* #946 Fixed variable name regression for the "list" format introduced with version 2.1.2
