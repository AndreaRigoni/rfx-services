# Semantic MediaWiki 2.2.2

Released on July 7th, 2015.

## Bug fixes

* #1067 Fixed return value of the `#set` parser
* #1081 Fixed mismatch of `owl:Class` for categories when used in connection with a vocabulary import
