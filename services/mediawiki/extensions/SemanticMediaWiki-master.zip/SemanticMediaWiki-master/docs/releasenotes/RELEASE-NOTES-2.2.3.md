# Semantic MediaWiki 2.2.3

Released on October 11th, 2015.

## Bug fixes

* #1201 Fixed php-serialization issue for `SemanticData`
