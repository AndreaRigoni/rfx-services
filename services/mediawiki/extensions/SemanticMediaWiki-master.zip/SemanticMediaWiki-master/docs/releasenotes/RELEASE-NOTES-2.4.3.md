# Semantic MediaWiki 2.4.3

Released on November 28nd, 2016.

## Bug fixes

* #1975 Fixed alias definitions for namspace "Type" causing notices due to the namespace being undefined
* <code>fd6b4cf</code> Fixed a compatibility breaking short array syntax for PHP 5.3
* <code>0ae3a3e</code> Added missing internal file loading
