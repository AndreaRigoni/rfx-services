# Semantic MediaWiki 2.4.4

Released on December 14, 2016.

## Bug fixes

* #2078 Fixed error for MySQL 5.7 causing "SELECT list; this is incompatible with DISTINCT"
* #2089 Fixed error for MySQL 5.7 causing "UPDATE - SET; Data too long for column"
