# Semantic MediaWiki 2.4.6

Released on February 15th, 2017.

## Enhancement

* #2235 Backport of #1758 - Add configuration parameter `$smwgQTemporaryTablesAutoCommitMode` allowing to create MySQL temp tables in auto commit mode
