# Semantic MediaWiki 4.0.0

Not released yet - under development

## Compatibility

* Dropped support for MediaWiki older than 1.35
* Dropped support for PHP older than 7.3

For more detailed information, see the [compatibility matrix](../COMPATIBILITY.md#compatibility).

## New features

## Enhancements
