This is a [MediaWiki Extension](https://www.mediawiki.org/wiki/Extension:SimpleTooltip) that adds basic tooltip capabilities. For Documentation see: https://www.mediawiki.org/wiki/Extension:SimpleTooltip

##Attribution
Uses the [Tooltipster Library](http://iamceege.github.io/tooltipster/) and [Fugue Icons](https://github.com/yusukekamiyamane/fugue-icons)